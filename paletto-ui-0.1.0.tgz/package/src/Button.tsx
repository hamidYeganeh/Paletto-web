import type { ButtonProps } from "./components/Button/button.types"
import { buttonStyles } from "./components/Button/button.styles"

export default function Button({ variant, size, className, ...props }: ButtonProps) {
  return <button {...props} className={buttonStyles({ variant, size, className })} />
}
